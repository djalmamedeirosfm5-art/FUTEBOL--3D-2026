extends Node3D

var elapsed := 0.0
var ball: MeshInstance3D

func _ready() -> void:
    _make_field()
    _make_ball()
    _make_hud()

func _process(delta: float) -> void:
    elapsed += delta
    if is_instance_valid(ball):
        ball.position.x = sin(elapsed * 1.1) * 2.2
        ball.position.z = cos(elapsed * 0.8) * 1.2

func _make_field() -> void:
    var ground := MeshInstance3D.new()
    var mesh := PlaneMesh.new()
    mesh.size = Vector2(28, 16)
    ground.mesh = mesh
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.08, 0.42, 0.16)
    ground.material_override = mat
    add_child(ground)

    var camera := Camera3D.new()
    camera.position = Vector3(0, 12, 17)
    camera.rotation_degrees = Vector3(-34, 0, 0)
    camera.current = true
    add_child(camera)

    var light := DirectionalLight3D.new()
    light.rotation_degrees = Vector3(-55, -25, 0)
    light.light_energy = 1.2
    add_child(light)

    _line(Vector3(0, 0.02, 0), Vector3(0.12, 0.02, 14), Color.WHITE)
    _line(Vector3(-13, 0.02, 0), Vector3(26, 0.02, 0.12), Color.WHITE)
    _line(Vector3(13, 0.02, 0), Vector3(26, 0.02, 0.12), Color.WHITE)
    _line(Vector3(0, 0.02, -7.8), Vector3(26, 0.02, 0.12), Color.WHITE)
    _line(Vector3(0, 0.02, 7.8), Vector3(26, 0.02, 0.12), Color.WHITE)

func _line(pos: Vector3, size: Vector3, color: Color) -> void:
    var node := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    node.mesh = box
    node.position = pos
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    node.material_override = mat
    add_child(node)

func _make_ball() -> void:
    ball = MeshInstance3D.new()
    var sphere := SphereMesh.new()
    sphere.radius = 0.35
    sphere.height = 0.7
    ball.mesh = sphere
    ball.position = Vector3(0, 0.4, 0)
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color.WHITE
    ball.material_override = mat
    add_child(ball)

func _make_hud() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var label := Label.new()
    label.text = "FUTEBOL 3D 2026  |  DEMONSTRAÇÃO"
    label.position = Vector2(24, 20)
    label.add_theme_font_size_override("font_size", 26)
    layer.add_child(label)
    var note := Label.new()
    note.text = "Projeto inicial para Android — controles e partidas serão adicionados nas próximas versões."
    note.position = Vector2(24, 58)
    note.add_theme_font_size_override("font_size", 16)
    layer.add_child(note)
